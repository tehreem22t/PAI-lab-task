from flask import Flask, render_template, request
import cv2
from ultralytics import YOLO
import folium
import os

app = Flask(__name__)

UPLOAD_FOLDER = "static/uploads"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

model = YOLO("yolov8n.pt")

# COCO animal classes
animal_classes = [
    "bird","cat","dog","horse","sheep",
    "cow","elephant","bear","zebra","giraffe"
]

def detect_animals(image_path):

    img = cv2.imread(image_path)

    results = model(img)

    animal_count = 0

    for r in results:
        for box in r.boxes:

            cls_id = int(box.cls)
            label = model.names[cls_id]

            if label in animal_classes:
                animal_count += 1

    herd = "No Herd"

    if animal_count >= 3:
        herd = "Herd Detected"

    return animal_count, herd


def create_map():

    lat = 31.5204
    lon = 74.3587

    m = folium.Map(location=[lat, lon], zoom_start=12)

    folium.Marker(
        [lat, lon],
        popup="Animal Herd Detected",
        icon=folium.Icon(color="red")
    ).add_to(m)

    m.save("templates/map.html")


@app.route("/", methods=["GET","POST"])
def index():

    result = None

    if request.method == "POST":

        file = request.files["image"]

        filepath = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)

        file.save(filepath)

        animals, herd = detect_animals(filepath)

        if herd == "Herd Detected":
            create_map()

        result = {
            "animals": animals,
            "herd": herd
        }

    return render_template("index.html", result=result)


@app.route("/map")
def map_view():
    return render_template("map.html")


if __name__ == "__main__":
    app.run(debug=True)